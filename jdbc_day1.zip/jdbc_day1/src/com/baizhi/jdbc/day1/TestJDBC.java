package com.baizhi.jdbc.day1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import org.junit.Test;

public class TestJDBC {
	
	
	@Test
	public void test1() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			//1.��������
			Class.forName("com.mysql.jdbc.Driver");  //����� 
			
			//2.����Connection
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb","root","admin");
			
			//3.����PreparedStatementִ��sql���
			pstmt = conn.prepareStatement("insert into t_user (name,password) values('good','123456')");
			pstmt.executeUpdate();
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("-----------");
		}finally {
			//�ر���Դ�����ȴ������رգ�
			if(pstmt != null) {
				try{
					pstmt.close();
					}catch(Exception e) {
						
					}
			}
			if(conn != null) { 
				try{
					conn.close();
					}catch(Exception e) {
						
					}
			}
		}
		
	}
}
