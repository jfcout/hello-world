package test;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestUserDAO {
	private static SqlSessionFactory sqlSessionFactory;
	private static SqlSession sqlSession;
	
	@BeforeClass
	public static void beforeClass() throws IOException {
		Reader reader = Resources.getResourceAsReader("mybatis-config.xml");  //InputStream is = Resources.getResourceAsStream("mybatis-config.xml");
		sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader);
		reader.close();		
	}
	
	@Before
	public void before() {
		sqlSession = sqlSessionFactory.openSession();
	}
	
	@Test                        //@Test(expected = IOException.class) ���������׳�IOException�쳣������׳�����ͨ�����ԣ�����failure
	public void test1() {
		
		User userZS = new User();
		userZS.setName("cjf15"); 
		userZS.setPassword("123456");
		
		UserDao userDAO = sqlSession.getMapper(UserDao.class);
		
		userDAO.save(userZS);
		
		User user3 = userDAO.queryUserById(userZS.getId());
		System.out.println("user name is "+user3.getName()+" " + user3.getId());
				
		sqlSession.commit();
		sqlSession.close();
		
	}
}
