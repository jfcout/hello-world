package test;

public interface UserDao {
	public User queryUserById(Integer id);
	public void save(User user);
}
 