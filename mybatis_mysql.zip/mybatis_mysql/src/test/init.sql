create database testdb;

create table t_user(
	id integer auto_increment primary key,
	name varchar(12),
	password varchar(12)
);

insert into t_user(name,password) values('suns','123456');
insert into t_user(name,password) values('xiaohei','123456');
